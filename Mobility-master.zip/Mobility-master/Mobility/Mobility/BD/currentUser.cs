﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Mobility.BD
{
    public class currentUser
    {
        public static int UserId { get; set; }
    }
}
